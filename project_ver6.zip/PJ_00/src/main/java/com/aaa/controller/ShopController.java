package com.aaa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ShopController {

    // 상점 메인 페이지 이동
    @GetMapping("/shop")
    public String shopPage() {
        // /WEB-INF/views/shop.jsp 로 이동
        return "comm/shop";
    }

}
