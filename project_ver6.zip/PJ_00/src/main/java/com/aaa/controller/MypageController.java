package com.aaa.controller;

import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.aaa.dto.MemberDto;

@Controller
public class MypageController {

    @GetMapping("/mypage")
    public String mypage(Model model, HttpSession session) {
        // 예시: 로그인한 사용자를 세션에서 가져오기
        MemberDto user = (MemberDto) session.getAttribute("loginUser");
        
        // 로그인 정보가 없으면 테스트용 기본 값 설정
        if (user == null) {
            user = new MemberDto();
            user.setId("test");
            user.setName("테스터");
        }

        model.addAttribute("user", user);
        return "comm/mypage"; // /WEB-INF/views/comm/mypage.jsp
    }
}
