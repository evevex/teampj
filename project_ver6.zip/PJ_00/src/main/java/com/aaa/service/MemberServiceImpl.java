package com.aaa.service;

import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import com.aaa.dto.MemberDto;
import com.aaa.mapper.MemberMapper;

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService {
  private final MemberMapper mapper;

  @Override
  public MemberDto findById(String id) {
    return mapper.findById(id);
  }

  @Override
  public MemberDto login(String id, String pw) {
    MemberDto user = mapper.findById(id);
    if (user == null) return null;

    // 데모용 평문 비교. 운영에서는 BCrypt.matches 사용 권장.
    if (user.getPw() != null && user.getPw().trim().equals(pw)) {
      return user;
    }
    return null;
  }
}