package com.aaa.service;

import java.util.ArrayList;

import org.springframework.ui.Model;

import com.aaa.dto.ComDto;


public interface ComService {
    ArrayList<ComDto> getList(int currentPage);
    Model getList(Model m, int currentPage, String sort); // 사용
    ComDto read(long bno);
    void del(long bno);
    void write(ComDto dto);
    void modify(ComDto dto);
}
