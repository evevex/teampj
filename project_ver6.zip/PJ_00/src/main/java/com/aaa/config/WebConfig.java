package com.aaa.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
  @Override
  public void addResourceHandlers(ResourceHandlerRegistry registry) {
    // src/main/webapp/resources/ 아래 정적 파일 요청 허용
    registry.addResourceHandler("/resources/**")
            .addResourceLocations("/resources/");
  }
}
