package com.aaa.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aaa.dto.CommentDto;
import com.aaa.mapper.CommentMapper;

@Service
public class CommentService {

    @Autowired
    private CommentMapper commentMapper;

    public List<CommentDto> getComments(Long bno) {
        return commentMapper.getCommentList(bno);
    }

    // 원댓글 등록 (XML에서 comment_group 자동 할당)
    public void addComment(Long bno, String writer, String content) {
        CommentDto dto = new CommentDto();
        dto.setBno(bno);
        dto.setWriter(writer);
        dto.setContent(content);
        commentMapper.insertComment(dto);
        System.out.println("insert 후 dto.getCno() = " + dto.getCno()); // ★ 이 줄 추가!
        commentMapper.updateCommentGroup(dto.getCno());
    }

    // 대댓글 등록 (순서 밀기 -> 대댓글 insert)
    public void addReply(Long bno, Long parentCno, String writer, String content,
                         Long commentGroup, int commentOrder, int depth) {
    	
    	System.out.println("받은 depth 값: " + depth);

        // 1. 같은 그룹에서 commentOrder가 해당 위치 이후인 것들 +1 처리
        Map<String, Object> param = new HashMap<>();
        param.put("commentGroup", commentGroup);
        param.put("commentOrder", commentOrder + 1);

        commentMapper.increaseCommentOrder(param);

        // 2. 대댓글 insert
        CommentDto dto = new CommentDto();
        dto.setBno(bno);
        dto.setWriter(writer);
        dto.setContent(content);
        dto.setParentCno(parentCno);
        dto.setDepth(depth + 1);
        dto.setCommentGroup(commentGroup);
        dto.setCommentOrder(commentOrder + 1);

        commentMapper.insertReply(dto);
    }
    
    

    public void deleteComment(Long cno) {
        commentMapper.deleteComment(cno);
    }
    
    
}