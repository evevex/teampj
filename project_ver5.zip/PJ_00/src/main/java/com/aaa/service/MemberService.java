package com.aaa.service;
import com.aaa.dto.MemberDto;

public interface MemberService {
  MemberDto findById(String id);
  MemberDto login(String id, String pw);
}