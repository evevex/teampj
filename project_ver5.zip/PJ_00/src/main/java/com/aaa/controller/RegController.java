package com.aaa.controller;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/auth/*")
@Controller

public class RegController {
	
	@GetMapping("/reg")
	public void reg() {
		log.info("reg ========== 접속");
	}

}
