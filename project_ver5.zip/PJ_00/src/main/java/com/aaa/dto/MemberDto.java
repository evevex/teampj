package com.aaa.dto;

import lombok.Data;

@Data
public class MemberDto {
    private String id;    // 로그인 ID
    private String pw;    // 비밀번호
    private String name;  // 이름
}
