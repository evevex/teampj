package com.aaa.dto;

import java.sql.Timestamp;
import lombok.Data;

@Data
public class CommentDto {
    private Long cno;           // 댓글 번호
    private Long bno;           // 해당 게시글 번호
    private String writer;      // 댓글 작성자
    private String content;     // 댓글 내용
    private Timestamp regdate;  // 작성일

    private Long parentCno;     // 부모 댓글 번호 (camelCase!)
    private int depth;          // 깊이 (0: 댓글, 1: 대댓글)
    private Long commentGroup;  // 그룹
    private int commentOrder;   // 순서
}