package com.aaa.service;

import javax.validation.Valid;

import com.aaa.dto.RegisterForm;

public interface UserService {

	void register(@Valid RegisterForm form);

}
