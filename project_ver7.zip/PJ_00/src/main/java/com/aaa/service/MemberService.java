package com.aaa.service;

import com.aaa.dto.MemberDto;

public interface MemberService {
    MemberDto findByLoginId(String loginId);
    MemberDto login(String loginId, String password);
}
