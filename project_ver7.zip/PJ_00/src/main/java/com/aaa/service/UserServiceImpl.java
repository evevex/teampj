package com.aaa.service;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.aaa.dto.RegisterForm;
import com.aaa.dto.UserDto;
import com.aaa.mapper.UserMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public void register(RegisterForm form) {
        // RegisterForm → User 엔티티 변환
        UserDto user = new UserDto();
        user.setLoginId(form.getLoginId());
        user.setFirstName(form.getFirstName());
        user.setLastName(form.getFirstName());
        user.setBirthDate(form.birthDate());   // LocalDate 변환 메서드 활용
        user.setGender(form.getGender());
        user.setContact(form.getContact());

        // 비밀번호 암호화
        String encodedPw = passwordEncoder.encode(form.getPassword());
        user.setPassword(encodedPw);

        // DB 저장
        userMapper.insertUser(user);
    }
}
