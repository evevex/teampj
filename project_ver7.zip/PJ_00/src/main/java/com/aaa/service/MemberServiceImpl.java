package com.aaa.service;

import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import com.aaa.dto.MemberDto;
import com.aaa.mapper.MemberMapper;

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService {
    private final MemberMapper mapper;

    @Override
    public MemberDto findByLoginId(String loginId) {
        return mapper.findById(loginId);
    }

    @Override
    public MemberDto login(String loginId, String password) {
        MemberDto user = mapper.findById(loginId);
        if (user == null) return null;

        // 데모용 평문 비교 (운영 시에는 BCrypt 사용 권장)
        if (user.getPassword() != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}
