package com.aaa.dto;

import java.time.LocalDate;
import lombok.Data;

@Data
public class MemberDto {
    private String loginId;     // 로그인 ID
    private String password;    // 비밀번호
    private String fullName;    // 전체 이름 (DB full_name 컬럼과 매핑)
    private String firstName;   // 이름
    private String lastName;    // 성
    private LocalDate birthDate; // 생년월일
    private String gender;      // 성별 (F, M, O)
    private String contact;     // 연락처 (휴대폰/이메일)
}
