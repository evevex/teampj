package com.aaa.dto;

import javax.validation.constraints.*;

import java.time.LocalDate;

public class RegisterForm {
  @NotBlank @Size(min=4, max=20)
  private String loginId;

  @NotBlank private String firstName;
  @NotBlank private String lastName;

  @NotNull @Min(1900) @Max(2100) private Integer birthYear;
  @NotNull @Min(1) @Max(12)       private Integer birthMonth;
  @NotNull @Min(1) @Max(31)       private Integer birthDay;

  @NotBlank @Pattern(regexp="F|M|O") private String gender;

  @NotBlank private String contact;

  @NotBlank @Size(min=8) private String password;

  // getters/setters

  public LocalDate birthDate(){ return LocalDate.of(birthYear, birthMonth, birthDay); }
  public String fullName(){ return lastName + firstName; }
public String getLoginId() {
	// TODO Auto-generated method stub
	return null;
}
public String getFirstName() {
	// TODO Auto-generated method stub
	return null;
}
public String getGender() {
	// TODO Auto-generated method stub
	return null;
}
public String getContact() {
	// TODO Auto-generated method stub
	return null;
}
public CharSequence getPassword() {
	// TODO Auto-generated method stub
	return null;
}
}
