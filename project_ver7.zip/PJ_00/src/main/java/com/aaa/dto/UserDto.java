package com.aaa.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
    private Long id;
    private String loginId;
    private String firstName;
    private String lastName;
    private LocalDate birthDate;
    private String gender;
    private String contact;
    // 보통 password는 제외 (조회/응답 DTO에는 민감정보 빼기)
	public void setPassword(String encodedPw) {
		// TODO Auto-generated method stub
		
	}
}
