package com.aaa.mapper;

import com.aaa.dto.UserDto;

public interface UserMapper {

	void insertUser(UserDto user);

}
