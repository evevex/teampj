package com.aaa.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.aaa.dto.CommentDto;

@Mapper
public interface CommentMapper {
    List<CommentDto> getCommentList(Long bno);

    void insertComment(CommentDto comment);
    void insertReply(CommentDto comment);

    void increaseCommentOrder(Map<String, Object> param);

    void deleteComment(Long cno);

	void updateCommentGroup(Long cno);
}