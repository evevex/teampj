package com.aaa.mapper;

import org.apache.ibatis.annotations.Param;
import com.aaa.dto.MemberDto;

public interface MemberMapper {
	MemberDto findById(@Param("loginId") String loginId);
  int insert(MemberDto dto); // 선택(가입용)
}