package com.aaa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aaa.dto.CommentDto;
import com.aaa.service.CommentService;

@Controller
@RequestMapping("/comm")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @GetMapping("/comments")
    @ResponseBody
    public List<CommentDto> getComments(@RequestParam Long bno) {
        return commentService.getComments(bno);
    }

    @PostMapping("/comments")
    @ResponseBody
    public String addComment(@RequestParam Long bno,
                              @RequestParam String writer,
                              @RequestParam String content) {
        commentService.addComment(bno, writer, content);
        return "success";
    }

    @PostMapping("/comments/delete")
    @ResponseBody
    public String deleteComment(@RequestParam Long cno) {
        commentService.deleteComment(cno);
        return "success";
    }
    
    @PostMapping("/comments/reply")
    @ResponseBody
    public String addReply(@RequestParam Long bno,
                           @RequestParam Long parentCno,
                           @RequestParam String writer,
                           @RequestParam String content,
                           @RequestParam Long commentGroup,
                           @RequestParam int commentOrder,
                           @RequestParam int depth) {
        commentService.addReply(bno, parentCno, writer, content, commentGroup, commentOrder, depth);
        return "success";
    }

}