package com.aaa.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.aaa.dto.RegisterForm;
import com.aaa.service.UserService; // 인터페이스 import

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/auth/*")
@RequiredArgsConstructor
@Log4j
public class RegController {

    private final UserService userService; // Impl 말고 인터페이스 주입

    @GetMapping("/reg")
    public String regForm(Model model) {
        model.addAttribute("registerForm", new RegisterForm());
        return "auth/reg"; // JSP (WEB-INF/views/auth/reg.jsp)
    }

    @PostMapping("/reg")
    public String register(
            @Valid @ModelAttribute("registerForm") RegisterForm form,
            BindingResult bindingResult,
            Model model) {

        if (bindingResult.hasErrors()) {
            log.warn("회원가입 입력값 오류: " + bindingResult);
            return "auth/reg"; // 에러 시 다시 회원가입 폼으로
        }

        try {
            userService.register(form);
        } catch (Exception e) {
            log.error("회원가입 실패", e);
            model.addAttribute("errorMessage", "회원가입 처리 중 오류 발생");
            return "auth/reg";
        }

        return "redirect:/auth/login"; // 성공 시 로그인 페이지 이동
    }
}
