package com.aaa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/games") // /games 로 통일
public class GameController {

    // 목록 페이지: /games
    @GetMapping
    public String list(Model model) {
        // 필요하면 카테고리/게임 리스트 주입
        // model.addAttribute("categories", ...);
        // model.addAttribute("games", ...);
        return "games/game"; // => /WEB-INF/views/games/game.jsp
    }

    // 실행 페이지: /games/film-house
    @GetMapping("/film-house")
    public String filmHouse() {
        return "games/film-house"; // => /WEB-INF/views/games/film-house.jsp
    }
    
    @GetMapping("/tetris")
    public String tetris() {
      return "games/tetris"; // /WEB-INF/views/games/tetris.jsp
    }

}
