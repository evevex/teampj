package com.aaa.controller;

import javax.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriUtils;

import com.aaa.dto.MemberDto;
import com.aaa.service.MemberService;

import java.nio.charset.StandardCharsets;

@Controller
@RequiredArgsConstructor
public class AuthController {

  private final MemberService memberService;

  // 로그인 페이지
  @GetMapping("/login")
  public String loginPage(@RequestParam(value="error", required=false) String error,
                          @RequestParam(value="redirect", required=false) String redirect,
                          Model model) {
    model.addAttribute("error", error);
    model.addAttribute("redirect", redirect);
    return "auth/login";
  }

  // 로그인 처리
  @PostMapping("/login")
  public String doLogin(@RequestParam String loginId,
                        @RequestParam String password,
                        @RequestParam(required=false) String redirect,
                        HttpSession session) {

    MemberDto user = memberService.login(loginId, password);
    if (user == null) {
      String q = redirect==null ? "" :
          "?redirect=" + UriUtils.encode(redirect, StandardCharsets.UTF_8) + "&error=1";
      return "redirect:/login" + (q.isEmpty()? "?error=1" : q);
    }

    session.setAttribute("loginUser", user);
    // 내부 경로만 허용 (open redirect 방지)
    String target = (redirect != null && redirect.startsWith("/")) ? redirect : "/comm/getList";
    return "redirect:" + target;
  }

  // 로그아웃
  @GetMapping("/logout")
  public String logout(@RequestHeader(value="Referer", required=false) String ref,
                       HttpSession session) {
    session.invalidate();
    return "redirect:" + (ref != null && ref.startsWith("/") ? ref : "/");
  }
}
