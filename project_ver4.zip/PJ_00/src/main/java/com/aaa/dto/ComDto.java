package com.aaa.dto;

import java.sql.Timestamp;
import lombok.Data;

@Data
public class ComDto {
    private Long bno;
    private String btext;
    private String btitle;  // 제목
    private String writer;  // 작성자
    private Integer hit;    // 조회수
    private Integer replyCnt;   // 댓글 수
    private Timestamp createdAt; // 작성일
}
