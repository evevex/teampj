package com.aaa.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.aaa.dto.ComDto;
import com.aaa.mapper.ComMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ComServiceImpl implements ComService {
	@Setter(onMethod_ = @Autowired)
	private ComMapper mapper;
	
	@Override
	public Model getList(Model m, int currentPage, String sort) {
	    int listCountPerPage = 5;
	    int pagesPerBlock = 3;

	    currentPage = Math.max(currentPage, 1);
	    int limitIndex = (currentPage - 1) * listCountPerPage;

	    // 화이트리스트(이외 값은 latest로 폴백)
	    if (!"popular".equals(sort) && !"latest".equals(sort)) {
	        sort = "latest";
	    }

	    m.addAttribute("list", mapper.getList(limitIndex, sort));

	    // 이하 페이징 계산 기존 그대로…
	    int count = mapper.getCount();
	    m.addAttribute("count", count);

	    int totalPageCount = (int) Math.ceil((double) count / listCountPerPage);
	    int pagesPerBlockCnt = pagesPerBlock;
	    int blockCount = (int) Math.ceil((double) totalPageCount / pagesPerBlockCnt);
	    int currentBlock = (int) Math.ceil((double) currentPage / pagesPerBlockCnt);
	    int blockStartPage = (currentBlock - 1) * pagesPerBlockCnt + 1;
	    int blockEndPage = Math.min(currentBlock * pagesPerBlockCnt, totalPageCount);

	    m.addAttribute("totalPageCount", totalPageCount);
	    m.addAttribute("pagesPerBlock", pagesPerBlockCnt);
	    m.addAttribute("blockCount", blockCount);
	    m.addAttribute("currentBlock", currentBlock);
	    m.addAttribute("blockStartPage", blockStartPage);
	    m.addAttribute("blockEndPage", blockEndPage);

	    if (currentBlock > 1) {
	        m.addAttribute("hasBlockPrev", true);
	        m.addAttribute("prevPage", (currentBlock - 1) * pagesPerBlockCnt);
	    }
	    if (currentBlock < blockCount) {
	        m.addAttribute("hasBlockNext", true);
	        m.addAttribute("nextPage", currentBlock * pagesPerBlockCnt + 1);
	    }
	    return m;
	}



	
	@Override
	public ArrayList<ComDto> getList(int currentPage) {
		log.info("비지니스 계층===========");
		int limitIndex = (currentPage-1) * 5;
		return mapper.getList(limitIndex);
	}
	
	
	
	@Override
	public ComDto read(long bno) {
		mapper.increaseHit(bno);
		return mapper.read(bno);
	}	
	
	@Override
	public void del(long bno) {
		mapper.del(bno);
	}
	
	@Override
	public void write(ComDto dto) {
		mapper.write(dto);
	}
	
	@Override
	public void modify(ComDto dto) {
		mapper.modify(dto);
	}	
	
}
