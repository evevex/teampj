package com.aaa.board;

public class Post {
	// 배웠던 게스트 게시판을 커뮤니티 게시판으로...??
	// 텍스트 게임 (전에 만들었던 코드 컴퓨터에서 찾아오기...)
	
	

}
