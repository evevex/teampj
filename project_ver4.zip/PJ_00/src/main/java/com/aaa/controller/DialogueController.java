package com.aaa.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@CrossOrigin(origins = {"http://localhost:3000","http://localhost:5173"})
@RestController
public class DialogueController {

    @GetMapping("/api/dialogue")
    public List<Map<String, Object>> getDialogue() {
        List<Map<String, Object>> dialogues = new ArrayList<>();

        // Scene 0: Prologue & Day 1, Scene 1
        Map<String, Object> scene0 = new HashMap<>();
        scene0.put("id", 0);
        scene0.put("text",
                "어제까지만 해도 세상은 멀쩡했다. 적어도 내가 아는 한에서는.\n" +
                "나는 뉴욕의 한 아파트에서 룸메이트와 살고 있었다.\n" +
                "아침이 된 지금, 룸메이트는 사라졌다.\n" +
                "온 집안을 뒤졌지만, 그 어떤 흔적도 찾을 수 없었다.\n" +
                "옆집의 올리버 스미스 씨와 부동산 업자, 심지어 집주인조차 그의 존재를 모르는 듯했다.\n" +
                "마치 그가 처음부터 이 세상에 없었던 것처럼.\n" +
                "나를 제외한 모두의 기억 속에서 그가 사라져버렸다.");
        scene0.put("choices", List.of(Map.of("label", "다음", "nextId", 1)));
        dialogues.add(scene0);

        // Scene 1: Day 1, Scene 2 (Found Camera & Film)
        Map<String, Object> scene1 = new HashMap<>();
        scene1.put("id", 1);
        scene1.put("text",
                "나는 거실로 나와 소파에 주저앉는다. 정리된 듯 차가운 거실에는 며칠 전까지 함께 웃고 떠들던 흔적이 없다.\n" +
                "그때, 책상 위에서 처음 보는 낡은 카메라와 필름 통 하나가 눈에 띈다.\n" +
                "필름 통에 붙어있는 메모가 눈에 들어온다. 룸메이트의 필체가 분명한데, 글씨가 마치 젖은 손으로 쓴 것처럼 흐릿하다.\n" +
                "\"현상하지 마시오.\" 나는 불안한 예감에 휩싸인다.");
        List<Map<String, Object>> choices1 = new ArrayList<>();
        choices1.add(Map.of("label", "필름을 서랍에 넣어둔다", "nextId", 2, "effects", Map.of("sanChange", 2)));
        choices1.add(Map.of("label", "호기심을 이기지 못하고 필름을 현상한다", "nextId", 2, "effects", Map.of("sanChange", -5, "flags", List.of("사진 속 세계 진입"))));
        choices1.add(Map.of("label", "카메라 자체를 부순다", "nextId", 2, "effects", Map.of("sanChange", -2, "ritualChange", -1, "flags", List.of("사진사 분노"))));
        scene1.put("choices", choices1);
        dialogues.add(scene1);

        // Scene 2: Day 1, Scene 3 (First Night)
        Map<String, Object> scene2 = new HashMap<>();
        scene2.put("id", 2);
        scene2.put("text",
                "하루 종일 룸메이트를 찾고 경찰에 신고까지 했지만, 모두들 내 말을 믿지 않는다.\n" +
                "나는 지칠 대로 지쳐 침대에 몸을 눕힌다.\n" +
                "꿈속에서 기묘한 감각을 느낀다. 나는 정신을 차려보니 아파트 복도에 서 있다.\n" +
                "모든 창문이 검은 안개로 덮여있고, 복도 끝의 검은 형체는 천천히 나에게 다가온다.\n" +
                "그에게서 희미하게 \"도망쳐…\" 라는 목소리가 들리는 것 같다.\n" +
                "이 아파트가, 사진이, 모두 뒤틀려 있다.");
        scene2.put("choices", List.of(Map.of("label", "다음 날로 넘어간다", "nextId", 3)));
        dialogues.add(scene2);

     // Scene 3: Day 2, Scene 1 (Oliver Smith)
        Map<String, Object> scene3 = new HashMap<>();
        scene3.put("id", 3);
        scene3.put("text",
                "아침, 엘리베이터 앞에서 옆집의 올리버 스미스 씨를 만난다.\n" +
                "그는 푸근한 미소를 짓고 있다. 나는 떨리는 목소리로 그에게 말을 건다.\n" +
                "나: \"안녕하세요, 스미스 씨. 혹시 여쭤볼게 있는데, 제 룸메이트 기억하세요?\"\n" +
                "올리버: (푸근한 미소를 지으며 고개를 갸웃거린다) \"룸메이트라니요? 아가씨, 혹시 친구가 놀러 왔나요? 어제도 본 적이 없는 것 같은데….\"\n" +
                "나는 그의 반응에 심장이 쿵 내려앉는다. 분명 어제는 그가 \"혼자 사는 줄 알았는데\"라고 말했었다. 그의 기억이 뒤죽박죽이다.\n" +
                "나: \"어제… 저랑 이야기하지 않으셨나요? 룸메이트에 대해서요. 이 방에… 저와 함께 살던 사람이요.\"\n" +
                "올리버: (표정이 굳어지며) \"흠, 글쎄요. 기억에 없네요. 피곤해서 착각한 모양입니다.\"\n" +
                "그는 나를 미심쩍은 눈빛으로 바라보더니, \"이제 아가씨 혼자 사는 거죠? 뭐, 도움이 필요하면 언제든지 말해요.\"라고 덧붙인다. 그의 말이 마치 '이곳에 당신 혼자뿐'이라고 강조하는 것처럼 들린다."
        );
        List<Map<String, Object>> choices3 = new ArrayList<>();
        choices3.add(Map.of("label", "이전에 촬영한 방 사진을 보여준다", "nextId", 4, "effects", Map.of("sanChange", -3)));
        choices3.add(Map.of("label", "올리버 스미스 씨를 촬영한다", "nextId", 4, "effects", Map.of("imageAdded", "올리버 스미스(2)")));
        choices3.add(Map.of("label", "침묵하고 지나친다", "nextId", 4, "effects", Map.of("flags", List.of("은밀 관찰"))));
        scene3.put("choices", choices3);
        dialogues.add(scene3);


        // Scene 4: Day 2, Scene 2 (Distorted Photo)
        Map<String, Object> scene4 = new HashMap<>();
        scene4.put("id", 4);
        scene4.put("text",
                "나는 불안함에 떨리는 손으로 어제 찍었던 올리버 스미스 씨의 사진을 꺼내본다.\n" +
                "사진 속 그의 얼굴이 섬뜩하게 일그러져 있다. 분명히 활짝 웃고 있었는데, 그의 입가에는 희미한 검은 실선이 그어져 있다.\n" +
                "마치 누군가 칼로 억지로 웃는 모습을 새겨 넣은 것처럼.\n" +
                "올리버 씨는 자신의 사진을 보더니 공포에 질려 비명을 지르며 도망친다. \"내가… 내가 아니야…!\"");
        scene4.put("choices", List.of(Map.of("label", "다음 장면으로", "nextId", 5)));
        dialogues.add(scene4);

        // Scene 5: Day 2, Scene 3 (Camera Shutter Sound)
        Map<String, Object> scene5 = new HashMap<>();
        scene5.put("id", 5);
        scene5.put("text",
                "밤이 되자 잠을 이룰 수 없다. 창밖에서 계속해서 '딸깍, 딸깍' 하는 카메라 셔터 소리가 들려온다.\n" +
                "나는 침대에 웅크리고 앉아 귀를 막는다. 낮게 웃는 목소리가 들리는 것 같지만, 나는 애써 무시하려 노력한다.");
        scene5.put("choices", List.of(Map.of("label", "다음 날로 넘어간다", "nextId", 6)));
        dialogues.add(scene5);

        // Scene 6: Day 3, Scene 1 (Corridor & Shadow)
        Map<String, Object> scene6 = new HashMap<>();
        scene6.put("id", 6);
        scene6.put("text",
                "아침, 묘한 위화감이 느껴져 복도 끝을 바라본다.\n" +
                "어제까지만 해도 굳게 닫혀 있던 옆집 문이 아주 미세하게 열려 있다.\n" +
                "틈 사이로 검은 그림자가 언뜻 스치는 것 같았지만, 눈을 비비고 다시 보니 문은 다시 굳게 닫혀 있다.\n" +
                "나는 조심스럽게 복도 끝으로 다가간다. 문틈에 귀를 대자, 안쪽에서 아주 희미하게 누군가 속삭이는 소리가 들린다.\n" +
                "그때, 뒤에서 '딸깍' 하고 셔터 소리가 들린다. 돌아보니 아무도 없다.");
        scene6.put("choices", List.of(Map.of("label", "다음 장면으로", "nextId", 7)));
        dialogues.add(scene6);

        // Scene 7: Day 3, Scene 2 (Delivered Photo)
        Map<String, Object> scene7 = new HashMap<>();
        scene7.put("id", 7);
        scene7.put("text",
                "현관문 아래 틈으로 얇은 봉투 하나가 들어와 있다. 어제 현상소에 맡긴 적 없는, 낯선 봉투다.\n" +
                "봉투를 여니, 어제 내가 찍었던 복도 사진이 나온다.\n" +
                "사진 속 복도 끝에 있던 희미한 검은 형체가 조금 더 또렷해져 있고, 사진 속 문이 마치 다른 층으로 연결된 듯한 느낌을 준다.\n" +
                "내 손이 미세하게 떨린다.\n" +
                "그때, 당신의 낡은 카메라가 '딸깍' 하고 혼자 셔터를 누르는 소리를 낸다.\n" +
                "불안한 예감에 창밖을 보니, 건너편 건물 창문에 누군가 서서 카메라를 들고 나를 향해 겨누고 있는 듯하다.\n" +
                "이내 그 사람은 검은 안개처럼 흐릿해지더니 사라진다.");
        List<Map<String, Object>> choices7 = new ArrayList<>();
        choices7.add(Map.of("label", "사진 속 세계로 들어가려 시도한다", "nextId", 8, "effects", Map.of("sanChange", -10, "flags", List.of("사진 속 세계 진입"))));
        choices7.add(Map.of("label", "사진을 찢어버린다", "nextId", 8, "effects", Map.of("sanChange", 3, "ritualChange", -1)));
        choices7.add(Map.of("label", "사진을 태운다", "nextId", 8, "effects", Map.of("sanChange", -6, "ritualChange", 1, "flags", List.of("불의 저항"))));
        scene7.put("choices", choices7);
        dialogues.add(scene7);

        // Scene 8: Day 3, Scene 3 (Nightmare)
        Map<String, Object> scene8 = new HashMap<>();
        scene8.put("id", 8);
        scene8.put("text",
                "밤이 되자, 현상된 사진 속 복도가 꿈에 반복적으로 등장한다.\n" +
                "벽에 걸린 액자 속 풍경은 시시각각 변하고, 창문 너머로는 끝없는 검은 안개가 보인다.\n" +
                "나는 복도를 헤매며 룸메이트의 이름을 부른다.\n" +
                "그때, 룸메이트의 목소리가 들려온다. 희미하고 멀지만 분명한 목소리.\n" +
                "\"도망쳐… 여긴… 안 돼…\" 그의 목소리는 내게 절망적인 경고를 던진다.\n" +
                "나는 이 모든 것이 사진 속 세계와 관련이 있음을 직감한다.");
        scene8.put("choices", List.of(Map.of("label", "다음 날로 넘어간다", "nextId", 9)));
        dialogues.add(scene8);

     // Scene 9: Day 4, Scene 1 & 2 (Distorted Memories)
        Map<String, Object> scene9 = new HashMap<>();
        scene9.put("id", 9);
        scene9.put("text",
                "장면 1: 커피숍의 재회\n" +
                "아침, 나는 머리를 식히기 위해 아파트 밖의 커피숍으로 향한다. 그곳에서 옆집 올리버 스미스 씨를 다시 만난다. 그는 나를 보고 푸근하게 웃는다.\n" +
                "나: \"안녕하세요, 올리버 씨. 어제는… 죄송했습니다. 제가 너무 예민했나 봐요.\"\n" +
                "올리버: \"하하, 괜찮아요. 그런데… 아가씨는 여기서 혼자 사는 것 아니었나요? 당신이 왜 그런 이야기를 하는지 이해가 안 가네요.\"\n" +
                "그의 눈동자가 흔들린다. 그는 내가 누군지 기억하지 못하는 듯하다. 마치 그와 어제의 대화는 없었던 일인 것처럼.\n" +
                "장면 2: 엘리베이터의 기억 조각\n" +
                "커피숍을 나와 아파트로 돌아온다. 엘리베이터에 타자, 안에 타고 있던 한 아주머니가 나를 보고 환하게 웃는다.\n" +
                "아주머니: \"어휴, 룸메이트랑 참 보기 좋았는데. 요새는 영 보이지를 않네.\"\n" +
                "아주머니의 말에 나는 심장이 쿵 내려앉는 것을 느낀다. 나는 떨리는 목소리로 묻는다.\n" +
                "나: \"아주머니… 제 룸메이트를 기억하세요?\"\n" +
                "아주머니: (고개를 갸웃하며) \"무슨 소리야? 당신 혼자 사는 거 아니었어? 아, 혹시 어제 그 친구 왔었나?\"\n" +
                "아주머니의 기억이 뒤죽박죽이다. 나는 더 이상 대화를 이어갈 수 없음을 느끼고 엘리베이터에서 내린다."
        );
        scene9.put("choices", List.of(Map.of("label", "다음 장면으로", "nextId", 10)));
        dialogues.add(scene9);


        // Scene 10: Day 4, Scene 3 (NPCs change)
        Map<String, Object> scene10 = new HashMap<>();
        scene10.put("id", 10);
        scene10.put("text",
                "나는 집으로 돌아와 사진을 꺼내본다. 어제 찍었던 올리버 스미스 씨와 아주머니 사진을 함께 본다.\n" +
                "사진 속 두 사람의 얼굴이 일그러지더니, 순식간에 완전히 다른 사람의 얼굴로 바뀌어 버린다.\n" +
                "그들의 눈은 텅 비어 있고, 마치 가면처럼 보인다.\n" +
                "나는 공포에 질려 사진을 내려놓는다. 아파트가 흔들리는 듯한 착각에 빠진다.\n" +
                "복도에서 희미하게 누군가 속삭이는 소리가 들려온다. \"당신도… 곧….\"");
        List<Map<String, Object>> choices10 = new ArrayList<>();
        choices10.add(Map.of("label", "사진을 다시 찍는다", "nextId", 11, "effects", Map.of("sanChange", -4, "flags", List.of("자아붕괴"))));
        choices10.add(Map.of("label", "사진을 찢는다", "nextId", 11, "effects", Map.of("sanChange", -1, "ritualChange", -1)));
        choices10.add(Map.of("label", "사진을 본다", "nextId", 11, "effects", Map.of()));
        scene10.put("choices", choices10);
        dialogues.add(scene10);

        // Scene 11: Day 5, Scene 1 (Strange Figure)
        Map<String, Object> scene11 = new HashMap<>();
        scene11.put("id", 11);
        scene11.put("text",
                "나는 사진들을 다시 살펴본다. 그중 한 장에서 낯선 인물이 카메라를 들고 있는 모습이 보인다.\n" +
                "나는 사진을 들고 창문으로 다가간다. 창밖으로 보이는 도시 풍경이 사진 속 풍경과 겹쳐 보이는 착각이 든다.\n" +
                "도시의 모습이 점차 흐릿해지더니, 검은 안개로 뒤덮인 모습으로 변한다.\n" +
                "나는 눈을 감았다 뜨지만, 이미 눈앞의 현실은 사진 속 세계와 뒤섞여 있다.");
        List<Map<String, Object>> choices11 = new ArrayList<>();
        choices11.add(Map.of("label", "바로 옥상으로 향한다", "nextId", 12));
        choices11.add(Map.of("label", "필름을 숨기고 나선다", "nextId", 12, "effects", Map.of("sanChange", -3, "flags", List.of("사진사 강화"))));
        choices11.add(Map.of("label", "룸메이트의 이름을 크게 외친다", "nextId", 12, "effects", Map.of("sanChange", 2, "flags", List.of("룸메이트 희미한 기억"))));
        scene11.put("choices", choices11);
        dialogues.add(scene11);

        // Scene 12: Day 5, Scene 2 & 3 (Film Whispers & The Photographer)
        Map<String, Object> scene12 = new HashMap<>();
        scene12.put("id", 12);
        scene12.put("text",
                "나는 카메라 옆에 놓여있던 필름 통을 집어든다. 필름 통을 흔들자, 물방울이 떨어지는 소리와 함께 낮게 웃는 목소리가 들려온다.\n" +
                "목소리: 어서 와… 너의 집으로…\n" +
                "나는 소름이 돋아 필름 통을 떨어뜨린다. 필름 통이 바닥에 굴러가더니 멈춘다.\n" +
                "그 순간, 나는 깨닫는다. 이 모든 일의 시작이 바로 이 필름이라는 것을.\n" +
                "나는 사진 속 인물의 위치를 찾기로 결심한다. 인물이 서 있는 곳이 이 아파트의 옥상이라는 것을 깨닫고, 나는 떨리는 손으로 카메라를 들고 옥상으로 향한다.\n" +
                "옥상 문을 열자, 사진 속의 그 인물이 카메라를 들고 나를 바라보고 있다.\n" +
                "그의 눈동자는 깊은 심연과 같고, 그의 입에서는 이해할 수 없는 언어가 흘러나온다.");
        scene12.put("choices", List.of(Map.of("label", "다음 날로 넘어간다", "nextId", 13)));
        dialogues.add(scene12);

        // Scene 13: Day 6, Scene 1 & 2 (Apartment Changes & Frozen Neighbors)
        Map<String, Object> scene13 = new HashMap<>();
        scene13.put("id", 13);
        scene13.put("text",
                "아침, 눈을 뜨자마자 이상한 기분에 사로잡힌다. 어제까지만 해도 멀쩡했던 방문이 뒤틀려 있다.\n" +
                "복도는 사진 속 구조와 일치하는 듯하다. 길었던 복도는 끝이 보이지 않고, 창문들은 검은 안개로 뒤덮여 있다.\n" +
                "나는 천천히 복도를 걸어간다. 몇몇 이웃이 '정지된 포즈'로 서 있다. 그들의 눈은 텅 비어 있고, 마치 마네킹 같다.\n" +
                "나는 공포에 질려 아주머니를 촬영한다. 카메라 셔터 소리가 울리고, 그녀는 마치 사진 속 배경처럼 사라져 버린다.");
        List<Map<String, Object>> choices13 = new ArrayList<>();
        choices13.add(Map.of("label", "촬영한다", "nextId", 14));
        choices13.add(Map.of("label", "그냥 지나친다", "nextId", 14));
        choices13.add(Map.of("label", "대화를 시도한다", "nextId", 14, "effects", Map.of("sanChange", -2, "ritualChange", 1, "flags", List.of("빛과 어둠의 단서"))));
        scene13.put("choices", choices13);
        dialogues.add(scene13);

        // Scene 14: Day 6, Scene 3 (Last Warning)
        Map<String, Object> scene14 = new HashMap<>();
        scene14.put("id", 14);
        scene14.put("text",
                "나는 공포에 질려 집으로 도망쳐 온다. 현관문 앞에 작은 봉투가 놓여 있다.\n" +
                "안에는 낡은 필름 한 통과 함께 찢어진 종잇조각이 들어있다. \"도망쳐… 여긴… 안 돼…\" 룸메이트의 필적이었다.\n" +
                "나는 절망에 빠진다. 더 이상 도망칠 곳은 없다.");
        scene14.put("choices", List.of(Map.of("label", "다음 날로 넘어간다", "nextId", 15)));
        dialogues.add(scene14);

        // Scene 15: Day 7, Final Choice
        Map<String, Object> scene15 = new HashMap<>();
        scene15.put("id", 15);
        scene15.put("type", "final-choice");
        scene15.put("text",
                "나는 떨리는 손으로 카메라를 든다. 그때, 복도 저 끝에서 한 남자가 걸어온다.\n" +
                "사진 속에서 보았던 바로 그 사진사였다.\n" +
                "그의 손에는 낡은 카메라가 들려 있다. 그의 눈동자는 깊은 심연과 같고, 그의 입에서는 이해할 수 없는 언어가 흘러나온다.\n" +
                "사진사: 이제… 너의 차례야. 너의 집으로 돌아가야지.\n" +
                "그가 말을 끝내기도 전에, 나의 귓가에 룸메이트의 목소리가 들려온다.\n" +
                "룸메이트: 기억해…! 그가 말했잖아…! '빛 대신 다른 차원의 어둠'… 그걸 바꿔야 해…!\n" +
                "나는 룸메이트의 마지막 경고를 떠올리며, 나의 모든 것을 건다.");
        List<Map<String, Object>> choices15 = new ArrayList<>();
        choices15.add(Map.of("label", "사진사를 촬영한다", "nextId", 16));
        choices15.add(Map.of("label", "사진사에게 맞선다", "nextId", 17));
        choices15.add(Map.of("label", "필름을 파괴한다", "nextId", 18));
        choices15.add(Map.of("label", "도망친다", "nextId", 19));
        choices15.add(Map.of("label", "모든 것을 포기한다", "nextId", 20));
        choices15.add(Map.of("label", "불길을 일으켜 모든 것을 태운다", "nextId", 21, "requiredFlag", "불의 저항"));
        choices15.add(Map.of("label", "룸메이트에게 모든 것을 맡긴다", "nextId", 22, "requiredFlag", "룸메이트 희미한 기억"));
        choices15.add(Map.of("label", "스스로 카메라를 든다", "nextId", 23, "requiredFlags", List.of("사진사 분노", "자아붕괴")));
        scene15.put("choices", choices15);
        dialogues.add(scene15);

        // Endings
        dialogues.add(createEnding(16, "희미한 기억 엔딩", "당신의 플래시가 터지는 순간, 아파트 전체가 격렬하게 흔들린다. 빛이 어둠을 집어삼키고, 사진사는 비명을 지르며 빛에 잠식당한다. 그가 사라진 자리에는 오직 낡은 카메라만 남아있다. 며칠 후, 당신은 병원에서 깨어난다. 룸메이트는 당신의 손을 잡고 있지만, 아파트에서 겪었던 모든 것을 희미한 악몽으로만 기억할 뿐이다. 당신들은 살아남았지만, 기억의 일부를 잃었고, 세상은 당신들을 존재하지 않는 사람들처럼 취급한다."));
        dialogues.add(createEnding(17, "의식 완성 엔딩", "당신은 사진사에게 달려들었지만, 그의 몸은 어둠으로 이루어져 있다. 당신의 몸은 점차 희미해지며 그의 일부가 된다. 그는 이제 당신의 자리를 차지할 것이다. 이윽고 모든 것이 검은 안개로 뒤덮이고, 거대한 존재가 현실에 강림한다. 당신은 새로운 '사진사'가 되어, 영원히 다음 피해자를 기다리게 될 것이다."));
        dialogues.add(createEnding(18, "기억 소거 엔딩", "당신은 모든 공포의 근원이 필름이라는 것을 깨닫고 마지막 남은 필름과 사진을 모두 불태운다. 종이가 타는 소리와 함께 아파트가 무너지는 듯한 굉음이 들린다. 당신은 의식을 잃는다. 깨어났을 때, 당신은 자신이 왜 이곳에 있는지조차 기억하지 못한다. 룸메이트에 대한 기억도, 이 아파트에 대한 기억도 모두 지워졌다. 당신은 영원히 이유를 모른 채 이 세계를 떠돌게 될 것이다."));
        dialogues.add(createEnding(19, "탈출 엔딩", "당신은 그를 피해 집으로 도망친다. 마지막 힘을 다해 문을 열자, 희미한 룸메이트의 목소리가 들린다. \"이곳을 떠나. 빨리.\" 당신은 간신히 아파트를 탈출한다. 그러나 당신과 룸메이트는 세상이 기억하지 못하는 존재가 되었다. 당신들은 영원히 서로를 의지하며 살아가야 할 것이다."));
        dialogues.add(createEnding(20, "방관자 엔딩", "당신은 모든 것을 외면하기로 한다. 이웃들의 소리는 완전히 사라지고, 복도는 고요하다. 창문은 검은 안개로 뒤덮여 있고, 밖으로 나가는 문은 사라졌다. 당신은 홀로 남는다. 이 아파트는 당신과 함께 영원히 미지의 공간에 갇히게 된다. 당신은 점점 무표정한 주민의 모습으로 변해갈 것이다."));
        dialogues.add(createEnding(21, "정화 엔딩", "불길로 필름을 태우자 사진사와 아파트가 모두 붉은 화염에 휩싸인다. 당신은 살아남지만, 불길 속에서 타오르는 룸메이트의 얼굴을 마지막으로 본다."));
        dialogues.add(createEnding(22, "희생 엔딩", "룸메이트가 대신 당신을 사진 속 세계로 끌어가며, 당신은 현실에 남는다. 그러나 아무도 룸메이트를 기억하지 않는다."));
        dialogues.add(createEnding(23, "왜곡 엔딩", "당신은 사진사와 자신이 구분되지 않음을 깨닫는다. 결국 스스로 카메라를 들고 복도를 찍으며 웃는다."));
        dialogues.add(createEnding(24, "동화 엔딩 (SAN 0)", "당신의 정신은 완전히 붕괴되었다. 현실과 이면 세계의 경계가 사라진 당신은, 더 이상 저항할 힘이 없다. 당신은 사진 속 세계에 흡수되어, 무표정한 주민이 된다. 당신은 매일 같은 시간에 엘리베이터에 서고, 창문 밖을 바라보며, 영원히 멈춰버린 사진 속 세상의 일부가 된다."));

        return dialogues;
    }

    private Map<String, Object> createEnding(int id, String title, String text) {
        Map<String, Object> ending = new HashMap<>();
        ending.put("id", id);
        ending.put("type", "ending");
        ending.put("title", title);
        ending.put("text", text);
        ending.put("choices", Collections.emptyList());
        return ending;
    }
}
