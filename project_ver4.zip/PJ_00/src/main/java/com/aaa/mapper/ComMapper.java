package com.aaa.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aaa.dto.ComDto;

public interface ComMapper {
    ArrayList<ComDto> getList(@Param("limitIndex") int limitIndex,
                              @Param("sort") String sort); // ⬅️ 추가
    ComDto read(long bno);
    void increaseHit(@Param("bno") long bno);
    void del(long bno);
    void write(ComDto dto);
    void modify(ComDto dto);
    int getCount();
	ArrayList<ComDto> getList(int limitIndex);
}

